# Bootstrap4-Audio-Playlist
An audio playlist using jQuery and the slider of jQuery-ui for functionality and Bootstrap4 and Material-UI font icons for styling.
- basic play/pause functionality
- next track button
- now playing indicator
- clickable progress bar from jQuery-UI
- clickable list items
- active list item featured with play icon and background color
- featured image
- easy to setup using html attributes audio_url and image_url on the list items
- easy to customize using Bootstrap and jQuery
- responsive
